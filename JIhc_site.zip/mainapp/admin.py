from django.contrib import admin
from .models import *
# Register your models here.


admin.site.register(SwiperImg)
admin.site.register(MainNewsPost)
admin.site.register(NavbarDropdownSpeciality)
admin.site.register(NavbarDropdownStudents)
admin.site.register(NavbarDropdownParents)
admin.site.register(NavbarDropdownAccept)
admin.site.register(NavbarDropdownColledge)
admin.site.register(NavbarDropdownDigitarium)
admin.site.register(MainTable)
admin.site.register(MainPost)
admin.site.register(MainPostSecond)
admin.site.register(Aboutuniverse)

admin.site.register(ForParents)

